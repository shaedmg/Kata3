package kata3;

public class Kata3 {

    public static void main(String[] arg){
        HistogramDisplay histo = new HistogramDisplay();
        histo.execute();
    }
}
